from OpenCV_Functions import *

processingMultipleImages(imageList_TrafficLightDetection())