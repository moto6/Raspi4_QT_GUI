from OpenCV_Functions import *

processingSingleImage(path_to_images())
#processingMultipleImages(imageList_TrafficLightDetection())
#processingMultipleImages(imageList_LaneDetection())
#processingSingleVideo(path_to_videos())
#processingMultipleVideos(videoList_LaneDetection())